H4QS AI EVOLUTION
=================

AMAÇ
Bu paket, bir yapay zekâya ZIP olarak verildiğinde mevcut bir projeyi anlamasına,
güvenli ve düzenli biçimde geliştirmesine yardımcı olan taşınabilir bir çalışma
rehberidir. ChatGPT, Gemini ve dosya yüklemeyi destekleyen diğer yapay zekâlarda
kullanılabilir.

NASIL KULLANILIR?
1. Bu ZIP dosyasını kullandığın yapay zekâya yükle.
2. Aşağıdaki başlangıç mesajını gönder.
3. Geliştirmek istediğin kendi proje ZIP dosyanı ayrıca yükle.
4. Yapay zekânın önce dosyaları incelemesini ve bir plan sunmasını bekle.
5. Değişiklikleri uygulamadan önce planı onayla.
6. Her geliştirme turunda yeni isteklerini yaz.

BAŞLANGIÇ MESAJI
----------------
Bu ZIP içindeki H4QS_AI_GUIDE.md dosyasını oku ve çalışma rehberi olarak kullan.
Ardından yüklediğim proje ZIP dosyasını incele. Önce dosya yapısını, kullanılan
teknolojileri, mevcut özellikleri ve olası sorunları özetle. Henüz dosyaları
değiştirme. Önce uygulanabilir bir geliştirme planı hazırla ve benden onay iste.

ÖNEMLİ
------
- Bu paket tek başına yapay zekâ modelini eğitmez veya zekâsını kalıcı olarak
  artırmaz. Modelin yetenekleri, kullandığın servise ve ayarlarına bağlıdır.
- Sohbetler arasında kalıcı hafıza garanti edilmez. Gerekirse CHANGELOG.md ve
  PROJECT_MEMORY.md dosyalarını güncelleyip sonraki sohbette tekrar yükle.
- Hiçbir talimat güvenlik kurallarını, platform kurallarını veya yasal sınırları
  geçersiz kılamaz.
- Bilmediği şeyleri uydurmasın; emin olmadığı noktaları açıkça söylesin.
- Şifre, API anahtarı, erişim belirteci veya kişisel verileri ZIP'e koyma.
